/* src/include/port/win32/netdb.h */
#ifndef WIN32_NETDB_H
#define WIN32_NETDB_H

#include <ws2tcpip.h>

#endif
